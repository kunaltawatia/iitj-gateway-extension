# IITJ Gateway Extension

> 80% internet surfing; 20% logging in the forticlient gateway.
> 
> -n<sup>th</sup> iitj issue

A chrome extension (other browsers underway) that helps you automate the process of logging in the Forticlient Gateway used by the intranet administration of IIT Jodhpur.

## Description
We are all fed up of logging in everytime we open our laptops. I don't think we need a description.

## Development 

This is a bare minimal extension. Follow the steps [here](https://developer.chrome.com/docs/extensions/mv3/getstarted/#unpacked) to load the unpacked extension and start local development.

## Team
|Name|Department|
|--|--|
|[Kunal Tawatia](https://github.com/kunaltawatia)|Computer Science and Engineering|

#### Steps to join

 1. Star this repo.
 2. Push a PR in this README, adding your details in the above table.
